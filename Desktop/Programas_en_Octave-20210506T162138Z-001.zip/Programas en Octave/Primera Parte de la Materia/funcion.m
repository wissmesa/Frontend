function y=funcion(x)
y=sin(x)-(1/(x+2));
