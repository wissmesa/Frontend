x=[1.5  2  3.4  4.1  4.9  6.1];
y=[0.3  1.8  3.9  10.3  15.4  20.7];
Y=log(y);
X=log(x);
p=polyfit(X,Y,1);
A=p(1);
B=p(2);
b=exp(B);
plot(x,y,'*');
hold on;
x=linspace(1,6.5,100);
plot(x,b*(x.^A));
A=p(1)
b=exp(B)

